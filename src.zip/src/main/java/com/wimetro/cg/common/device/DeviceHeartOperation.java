package com.wimetro.cg.common.device;

import com.wimetro.cg.protocol.message.Operation;

/**
 * @title: DeviceHeartOperation
 * @author: Ellie
 * @date: 2022/02/22 14:58
 * @description:
 **/
public class DeviceHeartOperation extends Operation {

//    @Override
//    public OperationResult execute() {
//        //
//        return null;
//    }
}
