package com.wimetro.cg.db.service;

import com.wimetro.cg.db.entity.DCgcgEmployeeDoor;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Ellie
 * @since 2023-05-26
 */
public interface DCgcgEmployeeDoorService extends IService<DCgcgEmployeeDoor> {

}
