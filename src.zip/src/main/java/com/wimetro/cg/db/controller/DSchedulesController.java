package com.wimetro.cg.db.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Ellie
 * @since 2023-05-23
 */
@RestController
@RequestMapping("/db/dSchedules")
public class DSchedulesController {

}
