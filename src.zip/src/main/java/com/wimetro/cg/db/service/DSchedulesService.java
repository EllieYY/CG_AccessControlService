package com.wimetro.cg.db.service;

import com.wimetro.cg.db.entity.DSchedules;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Ellie
 * @since 2023-05-23
 */
public interface DSchedulesService extends IService<DSchedules> {

}
