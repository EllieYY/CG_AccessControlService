package com.wimetro.cg.config.aop.excption;

/**
 * @Description :
 * @Author : Ellie
 * @Date : 2019/6/17
 */
public class ParamException extends RuntimeException {
    public ParamException(String msg) {
        super(msg);
    }
}
