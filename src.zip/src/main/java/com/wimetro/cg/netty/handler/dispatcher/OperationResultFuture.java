package com.wimetro.cg.netty.handler.dispatcher;

import com.wimetro.cg.protocol.message.DeviceMessage;
import io.netty.util.concurrent.DefaultPromise;

public class OperationResultFuture extends DefaultPromise<DeviceMessage> {
}
