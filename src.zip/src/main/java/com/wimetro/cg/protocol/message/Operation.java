package com.wimetro.cg.protocol.message;

/**
 * @title: Operation
 * @author: Ellie
 * @date: 2022/02/10 14:02
 * @description: 操作发起方
 **/
public abstract class Operation extends MessageBody {
//    public abstract OperationResult execute();
}
