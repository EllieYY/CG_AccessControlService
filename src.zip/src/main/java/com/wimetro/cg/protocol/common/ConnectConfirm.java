package com.wimetro.cg.protocol.common;

import com.wimetro.cg.protocol.message.OperationResult;
import lombok.Data;

/**
 * @title: ConnectConfirm
 * @author: Ellie
 * @date: 2023/04/07 16:06
 * @description:
 **/
@Data
public class ConnectConfirm extends OperationResult {
}
