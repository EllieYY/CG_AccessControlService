package com.wimetro.cg.protocol.message;

/**
 * @title: MessageBody
 * @author: Ellie
 * @date: 2022/02/10 11:28
 * @description:
 **/
public abstract class MessageBody {

}
