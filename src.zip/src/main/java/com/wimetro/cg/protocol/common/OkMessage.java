package com.wimetro.cg.protocol.common;

import com.wimetro.cg.protocol.message.OperationResult;
import lombok.Data;

/**
 * @title: OkMessage
 * @author: Ellie
 * @date: 2023/03/30 15:41
 * @description:
 **/
@Data
public class OkMessage extends OperationResult {
}
