package com.wimetro.cg.protocol.common;

import com.wimetro.cg.protocol.message.OperationResult;
import lombok.Data;

/**
 * @title: ConnectTest
 * @author: Ellie
 * @date: 2023/04/07 16:07
 * @description:
 **/
@Data
public class ConnectTest extends OperationResult {
}
