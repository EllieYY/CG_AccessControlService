package com.wimetro.cg.protocol.message;

import lombok.Data;

/**
 * @title: OperationResult
 * @author: Ellie
 * @date: 2022/02/10 14:03
 * @description: 操作响应方
 **/
@Data
public abstract class OperationResult extends MessageBody {
//    public abstract String getTargetIpString();
}
